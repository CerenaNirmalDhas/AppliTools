const browserCombo = [
    { width: 1200, height: 700, deviceName: 'laptop', name: 'firefox' },
    { width: 768, height: 700, deviceName: 'laptop', name: 'chrome' },
    { width: 375, height: 812, deviceName: 'iphone-x', screenOrientation: 'landscape', name:'chrome' }
]

context('Applitools', () => {
    beforeEach(() => {

        // Open the Applitools Test
        cy.eyesOpen({
            appName: 'Cross Browser Testing',
            browser: [
                { width: 1200, height: 700, name: 'chrome' },
                { width: 1200, height: 700, name: 'firefox' },
                { width: 768,  height: 700, name: 'chrome' },
                { width: 768,  height: 700, name: 'firefox' },
                { width: 375,  height: 812, name: 'chrome' },
                { width: 375, height: 812, name: 'firefox' },
                { deviceName: 'iPhone X', screenOrientation: 'landscape', name: 'chrome' }
            ]
        });

        cy.visit('https://demo.applitools.com/gridHackathonV2.html#0')
    });

    afterEach(() => {
        // Close the active test
        cy.eyesClose();
    })

    it('should see the applitools image', () => {

        // Wait on the page to load
        cy.get('#IMG____9').should('be.visible')

        // Take a snapshot of the whole page
        cy.eyesCheckWindow('Home page');
    })
	 });

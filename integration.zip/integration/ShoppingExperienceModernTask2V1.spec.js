const browserCombo = [
    { width: 1200, height: 700, deviceName: 'laptop', name: 'firefox' },
    { width: 768, height: 700, deviceName: 'laptop', name: 'chrome' },
    { width: 375, height: 812, deviceName: 'iphone-x', screenOrientation: 'landscape', name:'chrome' }
]

context('Applitools', () => {
    beforeEach(() => {

        // Open the Applitools Test
        cy.eyesOpen({
            appName: 'Cross Browser Testing',
            browser: [
                { width: 1200, height: 700, name: 'chrome' },
                { width: 1200, height: 700, name: 'firefox' },
                { width: 768,  height: 700, name: 'chrome' },
                { width: 768,  height: 700, name: 'firefox' },
                { width: 375,  height: 812, name: 'chrome' },
                { width: 375, height: 812, name: 'firefox' },
                { deviceName: 'iPhone X', screenOrientation: 'landscape', name: 'chrome' }
            ]
        });

        cy.visit('https://demo.applitools.com/gridHackathonV1.html#0')
    });

    afterEach(() => {
        // Close the active test
        cy.eyesClose();
    })

    it('should filter the black shoes/Shopping Experience test', () => {

        // Wait on the page to load
        cy.get('#SPAN__checkmark__107').click();
        cy.get('#filterBtn').click();

        // Take a snapshot of the whole page
        cy.eyesCheckWindow('Black shoes page');
    })
	 });

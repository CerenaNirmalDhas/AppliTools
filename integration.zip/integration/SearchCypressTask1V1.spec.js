const browserCombo = [
    { width: 1200, height: 700, deviceName: 'laptop' },
    { width: 768, height: 700, deviceName: 'laptop' },
    { width: 375, height: 812, deviceName: 'iphone-x' }
]

var count = 1;

describe('Cypress first test', () => {
    browserCombo.forEach(res => {
        it('should see the search box', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'search box', '.custom-search-input', res.width, res.height, res.deviceName);
        });
        it('should see the search icon', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'search icon', '.btn_search_mob', res.width, res.height, res.deviceName);
        });
        it('should see the personal icon', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'personal icon', '.access_link', res.width, res.height, res.deviceName);
        });
        it('should see the cart icon', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'cart button', '.cart_bt', res.width, res.height, res.deviceName);
        });
        it('should see the filter icon', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'filter icon', '.open_filters', res.width, res.height, res.deviceName);
        });
        it('should see the sort arrow', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'sort arrow', '#sort', res.width, res.height, res.deviceName);
        });
        it('should see the applifashion image', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'applifashion image', '#IMG____9', res.width, res.height, res.deviceName);
        });
        it('should see the offer image', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'offer image', '#SPAN__ribbonoff__212', res.width, res.height, res.deviceName);
        });
        it('should see the favorite image', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'favorite image', '#I__tiheart__225', res.width, res.height, res.deviceName);
        });
        it('should see the compare to image', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'compare to image', '#I__ticontrols__229', res.width, res.height, res.deviceName);
        });
        it('should see the add to cart image', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'add to cart image', '#I__tishopping__233', res.width, res.height, res.deviceName);
        });
        it('should see the type filter', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'type filter', '#A__opened__75', res.width, res.height, res.deviceName);
        });
        it('should see all the type filters', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'all type filters', '#UL____77', res.width, res.height, res.deviceName);
        });
        it('should see the color filter', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'color filter', '#A__opened__100', res.width, res.height, res.deviceName);
        });
        it('should see all the colors', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'all the colors', '#UL____102', res.width, res.height, res.deviceName);
        });
        it('should see the brand', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'brand filter', '#A__opened__130', res.width, res.height, res.deviceName);
        });
        it('should see all the brands', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'All the brands', '#UL____132', res.width, res.height, res.deviceName);
        });
        it('should see the price filter', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'price filter', '#A__opened__160', res.width, res.height, res.deviceName);
        });
        it('should see all the prices', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'all the prices', '#UL____162', res.width, res.height, res.deviceName);
        });
        it('should display the days left', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'display days left', '#DIV__countdown__216', res.width, res.height, res.deviceName);
        });
        it('should display the view grid', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'view grid', '#I__tiviewgrid__202', res.width, res.height, res.deviceName);
        });
        it('should display the view list', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'view list', '#I__tiviewlist__204', res.width, res.height, res.deviceName);
        });
        it('should display the shoe with its title and price', () => {
            cy.viewport(res.width, res.height);

            cy.visit('https://demo.applitools.com/gridHackathonV1.html');
            cy.shouldBeVisible(count++, 'shoe with title and price', '#DIV__griditem__211', res.width, res.height, res.deviceName);
        });
    });
});
